/**
 * 
 */
/**
 * 
 */
module JDBCApp {
	requires java.sql;
	requires mysql.connector.j;
}